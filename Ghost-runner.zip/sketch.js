var tower, towerImage;
var door, doorImage, doorGroup;
var climber, climberImage, climberGroup;
var ghost, ghostImage;
var gameState = "PLAY";
function preload(){
  towerImage = loadImage("tower.png");
  doorImage = loadImage("door.png");
  climberImage = loadImage("climber.png");
  ghostImage = loadImage("ghost-standing.png");
}
function setup(){
createCanvas(600,600)
  tower = createSprite(300,300);
  tower.addImage(towerImage);
  tower.scale= 1
  tower.velocityY = 3;
  doorGroup = new Group();
  climberGroup =new Group();
  ghost = createSprite(200,200);
  ghost.addImage(ghostImage);
  ghost.scale = 0.2
}
function draw(){
background(0);
drawSprites();

  if(gameState==="PLAY"){
  if(tower.y>600){
    tower.y = 300;
  }

    ghost.velocityY = ghost. velocityY+1;
if(keyDown("space")){
  ghost.velocityY = -5
}
if(keyDown(LEFT_ARROW)){
  ghost.x = ghost.x -10
}
if(keyDown(RIGHT_ARROW)){
  ghost.x = ghost.x +10
}
if(climberGroup.isTouching(ghost)||ghost.y>600){
   gameState= "END";
}
if(doorGroup.isTouching(ghost)){
ghost.velocityY = 0  
}
spawnDoors();
  }
  else if(gameState === "END"){
    ghost.destroy();
    text("GAME OVER",300,300);
  }
}

function spawnDoors(){
  if (frameCount % 150 === 0) {
    var door = createSprite(200,-50);
     door.x = Math.round(random(200,500));
     door.addImage( doorImage);
     door.scale = 1;
     door.velocityY = 3;
     doorGroup.add(door);
     //assign lifetime to the variable
    door.lifetime = 200;
    var climber = createSprite(200,10);
     climber.x =door.x; 
  climber .addImage( climberImage);
      climber.scale = 1;
     climber.velocityY = 3;
     climberGroup.add(climber);
     //assign lifetime to the variable
    climber.lifetime = 200;
    ghost.depth= door.depth+1;
     climber.debug = true;
    climber.setCollider("rectangle",0,10);
  }
  
}